import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero-data-engineering.jpg";
import snowflake from "@/assets/certs/snowflake.svg";
import aws from "@/assets/certs/aws.svg";
import fivetran from "@/assets/certs/fivetran.svg";
import cisco from "@/assets/certs/cisco.svg";
import juniper from "@/assets/certs/juniper.svg";
import microsoft from "@/assets/certs/microsoft.svg";
import coalesce from "@/assets/certs/coalesce.svg";
import { Mail, Github, Linkedin, Globe, Menu, X } from "lucide-react";
import { useTheme } from "next-themes";

const roles = [
  "Data Engineer",
  "Analytics Grad Student",
  "Cloud Enthusiast",
  "Snowflake Specialist",
];

const skills = [
  "Snowflake",
  "SQL",
  "Fivetran",
  "Matillion",
  "MuleSoft",
  "Snowpark Container Services",
  "Tableau",
  "Power BI",
  "Looker",
  "Streamlit",
  "AWS (EC2, S3, Glue)",
  "Docker",
  "Git",
  "CI/CD",
  "Azure DevOps",
  "Python",
  "R",
  "C",
];

const certifications = [
  { src: snowflake, alt: "Snowflake SnowPro" },
  { src: aws, alt: "AWS Cloud Practitioner" },
  { src: fivetran, alt: "Fivetran Certified" },
  { src: coalesce, alt: "Coalesce Fundamentals" },
  { src: microsoft, alt: "MTA Python" },
  { src: cisco, alt: "Cisco CCNA" },
  { src: juniper, alt: "Juniper JNCIA" },
];

const projects = [
  {
    title: "LEAF Accelerator – KPI & Use Cases Platform",
    period: "Sep 2024 – Dec 2024",
    stack: ["Snowflake", "Streamlit", "AWS"],
    summary:
      "Snowflake-backed Streamlit app surfacing 25k+ KPIs and 10k+ analytics use cases across multiple domains.",
  },
  {
    title: "PMO – Quality Gate Initiative",
    period: "Jun 2024 – Aug 2024",
    stack: ["Salesforce", "Excel"],
    summary:
      "Standardized quality gates across 100+ projects with integrated Salesforce checklists and automations.",
  },
  {
    title: "Financial Industrial Solutions – Geospatial Analytics",
    period: "Mar 2024 – May 2024",
    stack: ["Python", "Snowflake", "Streamlit"],
    summary:
      "Interactive maps with dynamic filters to explore millions of spatial records for insurance analytics.",
  },
  {
    title: "Oscar W. Larson Co. USA – Data Migration",
    period: "Jun 2023 – Feb 2024",
    stack: ["Snowflake", "MuleSoft", "Acumatica", "Sage"],
    summary:
      "Unified warehouse across 7 sources; 50+ MuleSoft pipelines with retries (99.5% reliability); reports cut from 4h to 15m.",
  },
  {
    title: "Query Analyzer – Snowflake Native App",
    period: "Feb 2023 – May 2023",
    stack: ["Snowflake", "Streamlit"],
    summary:
      "Marketplace app analyzing long-running queries with automated tuning recommendations; +60% performance.",
  },
  {
    title: "Industrial Solutions – LLM Model",
    period: "Nov 2022 – Jan 2023",
    stack: ["Python", "AWS", "Snowflake"],
    summary:
      "POC pipeline to answer questions from 10‑K/10‑Q filings; scraped PDFs to S3 and ingested into Snowflake.",
  },
  {
    title: "Kipi Stone – Real-Time Stock Market Analytics",
    period: "Sep 2022 – Oct 2022",
    stack: ["Snowflake", "Kafka", "Matillion", "Tableau", "AWS"],
    summary:
      "Sub‑second streaming of market feeds into Snowflake; orchestrated ETL and delivered interactive KPIs in Tableau.",
  },
  {
    title: "Snowflake Object Discovery",
    period: "Jul 2022 – Aug 2022",
    stack: ["Snowflake", "Streamlit", "Balsamiq"],
    summary:
      "Enterprise asset catalog: accounts, datasets, users, and roles to support governance.",
  },
  {
    title: "Blue Yonder Germany – Exasol → Snowflake Migration",
    period: "Jan 2022 – Jun 2022",
    stack: ["Snowflake", "Python", "Docker", "DBeaver", "Jira"],
    summary:
      "Migrated 300+ Exasol SQL templates; right‑sized warehouses and autosuspend for 18% compute cost reduction.",
  },
];

const experiences = [
  {
    company: "Kipi.ai",
    location: "Remote",
    period: "Oct 2021 – Dec 2024",
    role: "Lead Engineer · Senior Software Engineer · Software Engineer",
    bullets: [
      "Led a team of 4 to build the LEAF Accelerator Snowflake–Streamlit platform delivering 25,000+ KPIs; eliminated 400+ analyst hours quarterly and established CI/CD standards with 99.9% reliability.",
      "Architected an enterprise consolidation platform for Oscar W. Larson Co., integrating 7 sources (SQL Server, Acumatica, Sage) into Snowflake; engineered 50+ MuleSoft pipelines with retry and 99.5% reliability; reduced report time from 4h to 15m while processing 2M+ records daily.",
      "Mentored 6 engineers on Snowflake optimization and Matillion orchestration; co-designed accessible data models with business analysts.",
      "Executed Exasol→Snowflake migration at Blue Yonder converting 300+ templates, adding Python CI regression testing, and cutting compute costs by 18%.",
    ],
  },
  {
    company: "Oscar W. Larson Co.",
    location: "USA",
    period: "Jun 2023 – Feb 2024",
    role: "Senior Consultant",
    bullets: [
      "Built a multi-source Snowflake warehouse serving 100+ users with RBAC, documented row counts and performance metrics.",
      "Implemented 50+ MuleSoft pipelines with advanced error handling achieving 99.5% reliability; optimized with stored procedures and task scheduling.",
      "Established Git-based DevOps with automated deployments, reducing production incidents by 60%.",
    ],
  },
  {
    company: "Blue Yonder (Germany)",
    location: "Germany",
    period: "Jan 2022 – Jun 2022",
    role: "Consultant",
    bullets: [
      "Migrated 300+ Exasol SQL templates to Snowflake with improved accuracy and performance; right-sized warehouses and autosuspend for 18% compute savings.",
      "Prototyped Python & Docker workflows; resolved 50+ Jira issues with 98% on-time delivery.",
    ],
  },
];

function useTypedText(list: string[]) {
  const [text, setText] = useState("");
  const [i, setI] = useState(0);
  const [dir, setDir] = useState<"fwd" | "back">("fwd");
  useEffect(() => {
    const cur = list[i];
    let t: number;
    if (dir === "fwd") {
      t = window.setTimeout(() => {
        setText(cur.slice(0, text.length + 1));
        if (text.length + 1 === cur.length) setDir("back");
      }, 90);
    } else {
      t = window.setTimeout(() => {
        setText(cur.slice(0, text.length - 1));
        if (text.length - 1 === 0) {
          setDir("fwd");
          setI((i + 1) % list.length);
        }
      }, 45);
    }
    return () => clearTimeout(t);
  }, [text, dir, i, list]);
  useEffect(() => {
    const idle = window.setTimeout(() => setText(list[0].slice(0, 1)), 200);
    return () => clearTimeout(idle);
  }, []);
  return text;
}

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>(".reveal");
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.remove("opacity-0");
            e.target.classList.add("animate-enter");
            obs.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
}

function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const next = useMemo(() => (theme === "dark" ? "light" : "dark"), [theme]);
  return (
    <button
      aria-label="Toggle dark mode"
      onClick={() => setTheme(next)}
      className="h-9 w-9 inline-grid place-items-center rounded-md border border-border hover:bg-accent hover:text-accent-foreground transition-colors"
    >
      {/* Sun/Moon icon */}
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="h-5 w-5"
      >
        <circle cx="12" cy="12" r="5"></circle>
        <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
      </svg>
    </button>
  );
}

const Index = () => {
  useReveal();
  const typed = useTypedText(roles);
  const [open, setOpen] = useState(false);
  const yearRef = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    if (yearRef.current) yearRef.current.textContent = String(new Date().getFullYear());
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <header className="fixed inset-x-0 top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-background/70 border-b">
        <div className="container flex items-center justify-between h-16">
          <a href="#hero" className="text-sm md:text-base font-semibold tracking-wide story-link">
            Pullipudi S. M. S. H. Vamsi
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#about" className="hover:text-primary">About</a>
            <a href="#projects" className="hover:text-primary">Projects</a>
            <a href="#experience" className="hover:text-primary">Experience</a>
            <a href="#skills" className="hover:text-primary">Skills</a>
            <a href="#certs" className="hover:text-primary">Certifications</a>
            <a href="#education" className="hover:text-primary">Education</a>
            <a href="#connect" className="hover:text-primary">Connect</a>
          </nav>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <button
              aria-label="Menu"
              className="md:hidden h-9 w-9 inline-grid place-items-center rounded-md border border-border hover:bg-accent"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
        {open && (
          <nav className="md:hidden border-t bg-background">
            <div className="container py-4 flex flex-col gap-3 text-sm">
              {[
                ["About", "#about"],
                ["Projects", "#projects"],
                ["Experience", "#experience"],
                ["Skills", "#skills"],
                ["Certifications", "#certs"],
                ["Education", "#education"],
                ["Connect", "#connect"],
              ].map(([label, href]) => (
                <a key={href as string} href={href as string} onClick={() => setOpen(false)}>
                  {label}
                </a>
              ))}
            </div>
          </nav>
        )}
      </header>

      <main>
        {/* HERO */}
        <section id="hero" className="relative min-h-[90vh] pt-28 pb-16">
          <img
            src={heroImg}
            alt="Abstract data engineering background"
            className="absolute inset-0 h-full w-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/60 to-background/90" />
          <div className="relative container text-center">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">
              Hi, I'm <span className="text-primary">Vamsi Pullipudi</span>
            </h1>
            <p className="text-lg md:text-2xl text-muted-foreground mb-8">
              <span aria-live="polite">{typed}</span>
              <span className="ml-1 border-r animate-pulse" aria-hidden>
                &nbsp;
              </span>
            </p>
            <div className="flex items-center justify-center gap-3">
              <Button asChild variant="hero" className="hover-scale">
                <a href="#projects">See My Work</a>
              </Button>
              <Button asChild variant="outline" className="hover-scale">
                <a href="#connect">Get in Touch</a>
              </Button>
            </div>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="py-20 bg-card/50 reveal opacity-0">
          <div className="container max-w-3xl text-center">
            <h2 className="text-3xl font-bold mb-6">About Me</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Data Engineer / Data Analyst with 3+ years building reliable data platforms, scalable pipelines ingesting
              millions of records, and unified models enabling business insights. I automate ETL with Fivetran, Matillion,
              and MuleSoft, tune warehouse performance, and ensure data quality—communicating clearly with both
              technical and non-technical stakeholders to drive decision-making.
            </p>
          </div>
        </section>

        {/* PROJECTS */}
        <section id="projects" className="py-20 bg-muted/30 reveal opacity-0">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Projects</h2>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {projects.map((p) => (
                <article
                  key={p.title}
                  className="bg-card rounded-2xl border shadow-sm p-6 hover:shadow-md transition-shadow hover-scale"
                >
                  <h3 className="text-lg font-semibold mb-1">{p.title}</h3>
                  <p className="text-xs text-muted-foreground mb-2">{p.period}</p>
                  <p className="text-sm text-muted-foreground">{p.summary}</p>
                  <ul className="flex flex-wrap gap-2 text-xs mt-4 text-primary font-medium">
                    {p.stack.map((t) => (
                      <li key={t} className="px-2 py-1 rounded-full bg-secondary">
                        {t}
                      </li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* EXPERIENCE */}
        <section id="experience" className="py-20 bg-card reveal opacity-0">
          <div className="container max-w-4xl">
            <h2 className="text-3xl font-bold text-center mb-12">Experience</h2>
            <ul className="space-y-8">
              {experiences.map((ex) => (
                <li key={ex.company} className="p-6 rounded-2xl border bg-muted/30 backdrop-blur">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <h3 className="font-semibold text-lg">
                      {ex.company} · <span className="font-normal">{ex.role}</span>
                    </h3>
                    <span className="text-sm text-muted-foreground">{ex.location} · {ex.period}</span>
                  </div>
                  <ul className="mt-4 space-y-2 text-sm text-muted-foreground list-disc pl-5">
                    {ex.bullets.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* SKILLS */}
        <section id="skills" className="py-20 bg-muted/30 reveal opacity-0">
          <div className="container max-w-4xl text-center">
            <h2 className="text-3xl font-bold mb-10">Skills</h2>
            <div className="flex flex-wrap justify-center gap-3">
              {skills.map((s) => (
                <span key={s} className="px-4 py-2 bg-card rounded-full border shadow text-sm">
                  {s}
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* CERTIFICATIONS (logos only) */}
        <section id="certs" className="py-20 bg-card reveal opacity-0">
          <div className="container max-w-5xl">
            <h2 className="text-3xl font-bold text-center mb-12">Certifications</h2>
            <div className="grid grid-cols-3 md:grid-cols-7 gap-6 items-center">
              {certifications.map((c) => (
                <div
                  key={c.alt}
                  className="aspect-[3/2] md:aspect-[4/2] rounded-xl border bg-muted/40 flex items-center justify-center p-3 hover:shadow-md transition-shadow hover-scale"
                >
                  <img src={c.src} alt={`${c.alt} badge`} className="max-h-10 md:max-h-12 w-auto" loading="lazy" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* EDUCATION */}
        <section id="education" className="py-20 bg-muted/30 reveal opacity-0">
          <div className="container max-w-3xl">
            <h2 className="text-3xl font-bold text-center mb-12">Education</h2>
            <div className="space-y-6">
              <div className="p-6 rounded-2xl border bg-card/80 backdrop-blur">
                <h3 className="font-semibold text-lg">
                  M.S. Data Analytics Engineering – George Mason University
                  <span className="text-muted-foreground font-normal"> (Jan 2025 – May 2026)</span>
                </h3>
              </div>
              <div className="p-6 rounded-2xl border bg-card/80 backdrop-blur">
                <h3 className="font-semibold text-lg">
                  B.Tech Electronics & Communication – JNTU (Aditya College of Engineering & Technology)
                  <span className="text-muted-foreground font-normal"> (2018 – 2022)</span>
                </h3>
              </div>
            </div>
          </div>
        </section>

        {/* CONNECT */}
        <section id="connect" className="py-20 bg-card reveal opacity-0">
          <div className="container max-w-2xl text-center">
            <h2 className="text-3xl font-bold mb-6">Connect</h2>
            <p className="text-muted-foreground mb-6">
              Reach out via email or find me online — I'd love to chat!
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href="mailto:spullipu@gmail.com"
                className="inline-flex items-center gap-2 text-primary story-link"
              >
                <Mail className="h-4 w-4" /> spullipu@gmail.com
              </a>
              <a
                href="https://www.linkedin.com/in/pssharivamsi"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-primary story-link"
              >
                <Linkedin className="h-4 w-4" /> LinkedIn /pssharivamsi
              </a>
              <a
                href="https://github.com/PSSHARIVAMSI"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-primary story-link"
              >
                <Github className="h-4 w-4" /> GitHub /PSSHARIVAMSI
              </a>
              <a
                href="https://pssharivamsi.site"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-primary story-link"
              >
                <Globe className="h-4 w-4" /> pssharivamsi.site
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-6 text-center text-xs text-muted-foreground border-t">
        © <span ref={yearRef} /> S. M. S. H. Vamsi Pullipudi. All rights reserved.
      </footer>
    </div>
  );
};

export default Index;
